screenSize = 720
maxFPS = 60
images = list()